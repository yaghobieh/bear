export { BearLogo } from './BearLogo';
export type { BearLogoProps } from './BearLogo';
