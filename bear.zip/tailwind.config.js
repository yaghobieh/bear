/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  prefix: 'bear-',
  theme: {
    extend: {
      colors: {
        bear: {
          50: '#fef3c7',
          100: '#fde68a',
          200: '#fcd34d',
          300: '#fbbf24',
          400: '#f59e0b',
          500: '#d97706',
          600: '#b45309',
          700: '#92400e',
          800: '#78350f',
          900: '#451a03',
          950: '#1c0f00',
        },
        forge: {
          50: '#faf5ff',
          100: '#f3e8ff',
          200: '#e9d5ff',
          300: '#d8b4fe',
          400: '#c084fc',
          500: '#a855f7',
          600: '#9333ea',
          700: '#7c3aed',
          800: '#6b21a8',
          900: '#581c87',
          950: '#3b0764',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      borderRadius: {
        bear: '0.625rem',
      },
      boxShadow: {
        bear: '0 4px 14px 0 rgba(217, 119, 6, 0.15)',
        'bear-lg': '0 10px 40px 0 rgba(217, 119, 6, 0.2)',
      },
      animation: {
        'bear-pulse': 'bear-pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bear-glow': 'bear-glow 2s ease-in-out infinite',
        'bear-spin': 'spin 1s linear infinite',
        'bear-bounce': 'bounce 1s infinite',
      },
      keyframes: {
        'bear-pulse': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.5' },
        },
        'bear-glow': {
          '0%, 100%': { boxShadow: '0 0 5px rgba(217, 119, 6, 0.5)' },
          '50%': { boxShadow: '0 0 20px rgba(217, 119, 6, 0.8)' },
        },
      },
    },
  },
  plugins: [],
};

