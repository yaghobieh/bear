export { Switch } from './Switch';
export type { SwitchProps } from './Switch.types';

