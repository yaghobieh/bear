export { BearProvider, useBear, useBearTheme, useBearMode } from './BearProvider';
export { defaultLightTheme, defaultDarkTheme } from './defaultTheme';
