export { 
  Icon,
  CheckIcon,
  XIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  PlusIcon,
  MinusIcon,
  SearchIcon,
  MenuIcon,
  SettingsIcon,
  BearPawIcon,
  BearIcons,
} from './Icon';
export type { IconProps } from './Icon.types';
