import { FC, SVGAttributes } from 'react';

export interface BearLogoProps extends SVGAttributes<SVGElement> {
  /** Logo size in pixels */
  size?: number;
  /** Whether to show animated sparkle */
  animated?: boolean;
}

/**
 * BearLogo - Full body Lotso-inspired pink teddy bear logo
 * 
 * @example
 * ```tsx
 * <BearLogo size={48} />
 * <BearLogo size={32} animated />
 * ```
 */
export const BearLogo: FC<BearLogoProps> = ({ 
  size = 32, 
  animated = false,
  className,
  ...props 
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      className={className}
      {...props}
    >
      <defs>
        {/* Fur gradient - pink/raspberry like Lotso */}
        <radialGradient id="bearFurBody" cx="50%" cy="30%" r="70%" fx="50%" fy="30%">
          <stop offset="0%" stopColor="#f9a8d4" />
          <stop offset="50%" stopColor="#ec4899" />
          <stop offset="100%" stopColor="#be185d" />
        </radialGradient>
        {/* Light pink for belly/snout */}
        <radialGradient id="bearBelly" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fce7f3" />
          <stop offset="100%" stopColor="#fbcfe8" />
        </radialGradient>
        {/* Inner ear */}
        <radialGradient id="bearEarInner" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#fce7f3" />
          <stop offset="100%" stopColor="#f9a8d4" />
        </radialGradient>
      </defs>
      
      {/* Body */}
      <ellipse cx="50" cy="72" rx="28" ry="22" fill="url(#bearFurBody)" />
      {/* Belly patch */}
      <ellipse cx="50" cy="74" rx="18" ry="14" fill="url(#bearBelly)" />
      
      {/* Left arm */}
      <ellipse cx="22" cy="65" rx="10" ry="14" fill="url(#bearFurBody)" transform="rotate(-20 22 65)" />
      {/* Right arm */}
      <ellipse cx="78" cy="65" rx="10" ry="14" fill="url(#bearFurBody)" transform="rotate(20 78 65)" />
      
      {/* Left leg */}
      <ellipse cx="35" cy="90" rx="11" ry="8" fill="url(#bearFurBody)" />
      <ellipse cx="35" cy="90" rx="7" ry="5" fill="url(#bearBelly)" />
      {/* Right leg */}
      <ellipse cx="65" cy="90" rx="11" ry="8" fill="url(#bearFurBody)" />
      <ellipse cx="65" cy="90" rx="7" ry="5" fill="url(#bearBelly)" />
      
      {/* Head */}
      <ellipse cx="50" cy="35" rx="28" ry="26" fill="url(#bearFurBody)" />
      
      {/* Left ear */}
      <ellipse cx="26" cy="14" rx="12" ry="12" fill="url(#bearFurBody)" />
      <ellipse cx="26" cy="14" rx="7" ry="7" fill="url(#bearEarInner)" />
      {/* Right ear */}
      <ellipse cx="74" cy="14" rx="12" ry="12" fill="url(#bearFurBody)" />
      <ellipse cx="74" cy="14" rx="7" ry="7" fill="url(#bearEarInner)" />
      
      {/* Snout */}
      <ellipse cx="50" cy="42" rx="14" ry="11" fill="url(#bearBelly)" />
      
      {/* Nose - heart shape */}
      <path d="M50 40 L47 37 Q45 35 47 33 Q49 31 50 33 Q51 31 53 33 Q55 35 53 37 L50 40 Z" fill="#be185d" />
      
      {/* Left eye */}
      <ellipse cx="38" cy="30" rx="5" ry="6" fill="#1f2937" />
      <ellipse cx="36.5" cy="28.5" rx="2" ry="2.5" fill="#ffffff" />
      {/* Right eye */}
      <ellipse cx="62" cy="30" rx="5" ry="6" fill="#1f2937" />
      <ellipse cx="60.5" cy="28.5" rx="2" ry="2.5" fill="#ffffff" />
      
      {/* Smile */}
      <path d="M42 46 Q50 52 58 46" stroke="#be185d" strokeWidth="2" strokeLinecap="round" fill="none" />
      
      {/* Cheek blush */}
      <ellipse cx="28" cy="38" rx="5" ry="3" fill="#f472b6" opacity="0.5" />
      <ellipse cx="72" cy="38" rx="5" ry="3" fill="#f472b6" opacity="0.5" />
      
      {/* Animated sparkle */}
      {animated && (
        <g>
          <circle cx="85" cy="10" r="3" fill="#fbbf24">
            <animate
              attributeName="opacity"
              values="0;1;0"
              dur="2s"
              repeatCount="indefinite"
            />
            <animate
              attributeName="r"
              values="2;4;2"
              dur="2s"
              repeatCount="indefinite"
            />
          </circle>
          <path
            d="M83 10 L87 10 M85 8 L85 12"
            stroke="#fbbf24"
            strokeWidth="1.5"
            strokeLinecap="round"
          >
            <animate
              attributeName="opacity"
              values="0;1;0"
              dur="2s"
              repeatCount="indefinite"
            />
          </path>
        </g>
      )}
    </svg>
  );
};
