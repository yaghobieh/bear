import type { ButtonProps } from './Button';

export type { ButtonProps };

