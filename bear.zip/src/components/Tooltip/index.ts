export { Tooltip } from './Tooltip';
export type { TooltipProps } from './Tooltip';

